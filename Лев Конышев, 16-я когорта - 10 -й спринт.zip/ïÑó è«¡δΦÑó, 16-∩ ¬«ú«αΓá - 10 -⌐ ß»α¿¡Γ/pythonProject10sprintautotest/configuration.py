URL_SERVICE = "https://6568ee0c-aef7-4053-8cb3-38739907da2c.serverhub.praktikum-services.ru"  # URL_SERVICE хранит базовый URL веб-сервиса, который используется для доступа к API или другим ресурсам.
CREATE_USER_PATH = "/api/v1/users/"  # CREATE_USER_PATH хранит путь к API-методу для создания нового пользователя.
CREATE_KITS_PATH = "/api/v1/kits"    # CREATE_KITS_PATH хранит путь к API-методу для создания нового набора.
